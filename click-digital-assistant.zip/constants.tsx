
import { ServiceCategory, ServiceData, Ad } from './types';

export const BRAND_COLORS = {
  PURPLE: '#6b21a8',
  DARK_GRAY: '#111827',
  WHITE: '#ffffff'
};

export const WHATSAPP_NUMBER = '255765752918';
export const ADMIN_PASSWORD = 'click_digital';

export const TRANSLATIONS = {
  EN: {
    welcome: "Welcome to Click Digital",
    welcomeSub: "We are your all-in-one partner for graphic design, web solutions, and digital growth.",
    getStarted: "Start My Order",
    browseServices: "Select a Service",
    summary: "Order Summary",
    total: "Total Estimate",
    placeOrder: "Place Order on WhatsApp",
    delivery: "Estimated Delivery",
    back: "Go Back",
    admin: "Admin Access",
    addAd: "Add New Promotion",
    noAds: "No current promotions.",
    nextSteps: "Next Steps",
    nextStepsDesc: "After clicking below, your order details will be sent to Click Digital via WhatsApp. We will confirm details and share payment instructions.",
    emptyCart: "Your order is empty",
    goBack: "Browse Services",
    adminTitle: "Admin Panel",
    password: "Enter Admin Password",
    login: "Login",
    save: "Publish Ad",
    delete: "Remove",
    headline: "Ad Headline",
    imageUrl: "Banner Image",
    uploadImage: "Upload Image",
    imagePreview: "Image Preview",
    linkUrl: "Link (optional)",
    assistantGreeting: "Hello! I'm your Click Digital Assistant. How can I help you today?",
    fastDelivery: "Fast Delivery",
    trustedQuality: "Trusted Quality"
  },
  SW: {
    welcome: "Karibu Click Digital",
    welcomeSub: "Sisi ni mshirika wako wa kila kitu kwa ubunifu wa picha, mifumo ya tovuti, na ukuaji wa kidijitali.",
    getStarted: "Anza Agizo Lako",
    browseServices: "Chagua Huduma",
    summary: "Muhtasari wa Agizo",
    total: "Kadirio la Jumla",
    placeOrder: "Agiza kupitia WhatsApp",
    delivery: "Muda wa Kukamilisha",
    back: "Rudi Nyuma",
    admin: "Ingia kama Admin",
    addAd: "Ongeza Tangazo Jipya",
    noAds: "Hakuna matangazo kwa sasa.",
    nextSteps: "Hatua Zinazofuata",
    nextStepsDesc: "Baada ya kubonyeza hapa chini, maelezo ya agizo lako yatatumwa kwa Click Digital kupitia WhatsApp. Tutathibitisha na kukupa maelekezo ya malipo.",
    emptyCart: "Agizo lako ni tupu",
    goBack: "Angalia Huduma",
    adminTitle: "Jopo la Usimamizi",
    password: "Weka Nenosiri la Admin",
    login: "Ingia",
    save: "Chapisha Tangazo",
    delete: "Futa",
    headline: "Kichwa cha Tangazo",
    imageUrl: "Picha ya Bango",
    uploadImage: "Pakia Picha",
    imagePreview: "Onyesho la Picha",
    linkUrl: "Link (hiari)",
    assistantGreeting: "Habari! Mimi ni Msaidizi wa Click Digital. Nikusaidie nini leo?",
    fastDelivery: "Uwasilishaji wa Haraka",
    trustedQuality: "Ubora Unaaminika"
  }
};

export const SERVICES: ServiceData[] = [
  {
    category: ServiceCategory.GRAPHIC_DESIGN,
    categoryLabel: { EN: "Graphic Design", SW: "Ubunifu wa Michoro" },
    description: { 
      EN: "Professional logos and branding materials.",
      SW: "Logo za kitaalamu na vifaa vya chapa."
    },
    options: [
      {
        id: 'logo-basic',
        name: { EN: 'Logo Design (Basic)', SW: 'Ubunifu wa Logo (Kawaida)' },
        price: 30000,
        deliveryTime: { EN: '2-3 Days', SW: 'Siku 2-3' },
        description: { EN: 'Perfect for new startups.', SW: 'Inafaa kwa biashara mpya.' },
        includes: { EN: ['2 Concepts', 'High-res PNG'], SW: ['Macho 2', 'PNG ya Ubora'] }
      },
      {
        id: 'logo-standard',
        name: { EN: 'Logo Design (Standard)', SW: 'Ubunifu wa Logo (Standard)' },
        price: 50000,
        deliveryTime: { EN: '3-5 Days', SW: 'Siku 3-5' },
        description: { EN: 'Professional identity with source files.', SW: 'Utambulisho wa kitaalamu na mafaili asilia.' },
        includes: { EN: ['3 Concepts', 'Source Files'], SW: ['Macho 3', 'Mafaili Asilia'] }
      },
      {
        id: 'brand-kit',
        name: { EN: 'Premium Brand Kit', SW: 'Kifurushi cha Chapa (Premium)' },
        price: 100000,
        deliveryTime: { EN: '7-10 Days', SW: 'Siku 7-10' },
        description: { EN: 'Full visual identity system.', SW: 'Mfumo kamili wa utambulisho wa picha.' },
        includes: { EN: ['Logo Set', 'Brand Guidelines'], SW: ['Seti ya Logo', 'Mwongozo wa Chapa'] }
      },
      {
        id: 'poster-single',
        name: { EN: 'Poster or Flyer (Single)', SW: 'Poster au Flyer (Moja)' },
        price: 10000,
        deliveryTime: { EN: '1-2 Days', SW: 'Siku 1-2' },
        description: { EN: 'Single professional flyer design.', SW: 'Ubunifu wa bango moja la kitaalamu.' },
        includes: { EN: ['High-res Design', 'Print Ready'], SW: ['Ubunifu Bora', 'Tayari kwa Kuchapwa'] }
      },
      {
        id: 'poster-pack',
        name: { EN: 'Poster/Flyer (Package of 5)', SW: 'Poster/Flyer (Kifurushi cha 5)' },
        price: 50000,
        deliveryTime: { EN: '4-6 Days', SW: 'Siku 4-6' },
        description: { EN: 'Bundle of 5 consistent designs.', SW: 'Seti ya mabango 5 yenye muonekano mmoja.' },
        includes: { EN: ['5 Unique Designs', 'Source Files'], SW: ['Mabango 5 Tofauti', 'Mafaili Asilia'] }
      }
    ]
  },
  {
    category: ServiceCategory.WEBSITE_DESIGN,
    categoryLabel: { EN: "Website Design", SW: "Ubunifu wa Tovuti" },
    description: { EN: "Web solutions without complex backend requirements.", SW: "Mifumo ya tovuti isiyo na mahitaji makubwa ya mfumo wa ndani." },
    options: [
      {
        id: 'web-one-page',
        name: { EN: 'One-Page Website', SW: 'Tovuti ya Ukurasa Mmoja' },
        price: 200000,
        deliveryTime: { EN: '7-10 Days', SW: 'Siku 7-10' },
        description: { EN: 'Modern landing page for your brand.', SW: 'Ukurasa wa kisasa kwa ajili ya chapa yako.' },
        includes: { EN: ['Responsive Design', 'Contact Info'], SW: ['Inakaa vizuri kwenye simu', 'Mawasiliano'] }
      },
      {
        id: 'web-business',
        name: { EN: 'Business Website (3–5 pages)', SW: 'Tovuti ya Biashara (Kurasa 3-5)' },
        price: 450000,
        deliveryTime: { EN: '14-21 Days', SW: 'Siku 14-21' },
        description: { EN: 'Complete corporate website.', SW: 'Tovuti kamili ya kampuni.' },
        includes: { EN: ['Up to 5 Pages', 'SEO Basics'], SW: ['Hadi Kurasa 5', 'SEO ya Msingi'] }
      }
    ]
  },
  {
    category: ServiceCategory.SOCIAL_MEDIA,
    categoryLabel: { EN: "Social Media Design", SW: "Ubunifu wa Mitandao" },
    description: { EN: "Consistent and engaging social media content.", SW: "Maudhui ya kuvutia ya mitandao ya kijamii." },
    options: [
      {
        id: 'social-5',
        name: { EN: '5 Social Media Designs', SW: 'Mabango 5 ya Mitandao' },
        price: 30000,
        deliveryTime: { EN: '3-4 Days', SW: 'Siku 3-4' },
        description: { EN: 'Weekly content batch.', SW: 'Maudhui kwa ajili ya wiki moja.' },
        includes: { EN: ['5 Post Designs', 'Platform Optimized'], SW: ['Mabango 5', 'Kwa ajili ya simu'] }
      },
      {
        id: 'social-10',
        name: { EN: '10 Social Media Designs', SW: 'Mabango 10 ya Mitandao' },
        price: 60000,
        deliveryTime: { EN: '5-7 Days', SW: 'Siku 5-7' },
        description: { EN: 'Bi-weekly content batch.', SW: 'Maudhui kwa ajili ya wiki mbili.' },
        includes: { EN: ['10 Post Designs', 'Story Formats'], SW: ['Mabango 10', 'Format za Story'] }
      }
    ]
  },
  {
    category: ServiceCategory.QR_SOLUTIONS,
    categoryLabel: { EN: "QR Code Solutions", SW: "Huduma za QR Code" },
    description: { EN: "Scan-to-action digital solutions.", SW: "Mifumo ya QR ya kidijitali." },
    options: [
      {
        id: 'qr-single',
        name: { EN: 'Single QR Code', SW: 'QR Code Moja' },
        price: 10000,
        deliveryTime: { EN: '24 Hours', SW: 'Saa 24' },
        description: { EN: 'Branded QR code for links.', SW: 'QR Code yenye chapa kwa ajili ya link.' },
        includes: { EN: ['Custom Colors', 'High-res QR'], SW: ['Rangi Maalum', 'QR ya Ubora'] }
      },
      {
        id: 'qr-poster',
        name: { EN: 'QR Code with Poster Integration', SW: 'QR Code na Bango' },
        price: 25000,
        deliveryTime: { EN: '2 Days', SW: 'Siku 2' },
        description: { EN: 'A poster with integrated QR scan.', SW: 'Bango lenye QR Code inayosomeka.' },
        includes: { EN: ['1 Poster Design', 'QR Placement'], SW: ['Ubunifu wa Bango', 'QR Code'] }
      }
    ]
  },
  {
    category: ServiceCategory.LINK_IN_BIO,
    categoryLabel: { EN: "Link-in-Bio Setup", SW: "Mpangilio wa Link-in-Bio" },
    description: { EN: "One link for all your platforms.", SW: "Link moja kwa majukwaa yako yote." },
    options: [
      {
        id: 'link-bio',
        name: { EN: 'Link-in-Bio Setup', SW: 'Mpangilio wa Link-in-Bio' },
        price: 25000,
        deliveryTime: { EN: '2-3 Days', SW: 'Siku 2-3' },
        description: { EN: 'Mobile-friendly landing page.', SW: 'Ukurasa mwepesi wa simu.' },
        includes: { EN: ['Platform Setup', 'All Social Links'], SW: ['Mpangilio wa Mfumo', 'Links zote za Jamii'] }
      }
    ]
  }
];

export const INITIAL_ADS: Ad[] = [
  {
    id: '1',
    text: 'Upgrade your business with a professional Website! Starting from 200k.',
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1200',
    link: '',
    active: true
  }
];

export const PREDEFINED_QUESTIONS = {
  EN: ["What do I get with this service?", "How long will it take?", "Can I use this on social media?", "How do I pay?"],
  SW: ["Nini nitapata kwenye huduma hii?", "Itachukua muda gani?", "Naweza kutumia kwenye mitandao ya kijamii?", "Ninalipaje?"]
};
