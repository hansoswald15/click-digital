
import React, { useState, useMemo, useEffect } from 'react';
import { SERVICES, WHATSAPP_NUMBER, TRANSLATIONS, INITIAL_ADS, ADMIN_PASSWORD } from './constants';
import { ServiceCategory, CartItem, ServiceOption, Language, Ad } from './types';
import Assistant from './components/Assistant';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('EN');
  const [activeCategory, setActiveCategory] = useState<ServiceCategory | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showAssistant, setShowAssistant] = useState(false);
  const [step, setStep] = useState<'welcome' | 'browse' | 'summary' | 'admin'>('welcome');
  const [ads, setAds] = useState<Ad[]>([]);
  const [globalLogo, setGlobalLogo] = useState<string>('logo.png');
  
  // Admin state
  const [adminAuth, setAdminAuth] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [newAd, setNewAd] = useState<Partial<Ad>>({ text: '', link: '' });
  const [previewAdImage, setPreviewAdImage] = useState<string | null>(null);
  const [previewLogo, setPreviewLogo] = useState<string | null>(null);

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    // Load Ads
    const savedAds = localStorage.getItem('click_digital_ads');
    if (savedAds) {
      setAds(JSON.parse(savedAds));
    } else {
      setAds(INITIAL_ADS);
    }

    // Load Logo
    const savedLogo = localStorage.getItem('click_digital_logo');
    if (savedLogo) {
      setGlobalLogo(savedLogo);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('click_digital_ads', JSON.stringify(ads));
  }, [ads]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
    }).format(amount).replace('TZS', 'TZS ');
  };

  const addToCart = (category: ServiceCategory, categoryLabel: string, option: ServiceOption) => {
    const newItem: CartItem = {
      serviceId: option.id,
      category,
      optionName: option.name[lang],
      price: option.price
    };
    setCart(prev => [...prev, newItem]);
    setStep('summary');
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const totalPrice = useMemo(() => cart.reduce((sum, item) => sum + item.price, 0), [cart]);

  const sendToWhatsApp = () => {
    const header = lang === 'EN' ? '*Click Digital Order Request*' : '*Ombi la Agizo la Click Digital*';
    const totalLabel = lang === 'EN' ? 'Total Estimate' : 'Kadirio la Jumla';
    const nextSteps = lang === 'EN' ? 'I would like to proceed with the above order.' : 'Ningependa kuendelea na agizo hapo juu.';

    const message = `${header}\n\n` +
      cart.map((item, i) => `${i + 1}. ${item.optionName} - ${formatCurrency(item.price)}`).join('\n') +
      `\n\n*${totalLabel}: ${formatCurrency(totalPrice)}*` +
      `\n\n${nextSteps}`;
    
    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`, '_blank');
  };

  const handleAdminLogin = () => {
    if (passwordInput === ADMIN_PASSWORD) {
      setAdminAuth(true);
    } else {
      alert(lang === 'EN' ? "Invalid admin password" : "Nenosiri la admin si sahihi");
    }
  };

  const handleAdFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewAdImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewLogo(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addAd = () => {
    if (!newAd.text || !previewAdImage) return;
    const ad: Ad = {
      id: Date.now().toString(),
      text: newAd.text!,
      imageUrl: previewAdImage,
      link: newAd.link || '',
      active: true
    };
    setAds([...ads, ad]);
    setNewAd({ text: '', link: '' });
    setPreviewAdImage(null);
  };

  const saveLogo = () => {
    if (!previewLogo) return;
    setGlobalLogo(previewLogo);
    localStorage.setItem('click_digital_logo', previewLogo);
    setPreviewLogo(null);
    alert(lang === 'EN' ? "Logo updated successfully!" : "Logo imesasishwa kikamilifu!");
  };

  const deleteAd = (id: string) => {
    setAds(ads.filter(a => a.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24 font-sans text-gray-900">
      {/* Navigation / Language Toggle */}
      <div className="fixed top-4 right-4 z-50 flex gap-2">
        <button 
          onClick={() => setLang(lang === 'EN' ? 'SW' : 'EN')}
          className="bg-white/95 backdrop-blur px-5 py-2.5 rounded-2xl shadow-xl border border-purple-100 text-purple-700 font-bold text-xs flex items-center gap-2 hover:bg-purple-50 transition-all"
        >
          <i className="fas fa-language text-lg"></i>
          {lang === 'EN' ? 'Switch to SW' : 'Tumia EN'}
        </button>
      </div>

      {/* Header */}
      <header className="purple-gradient text-white px-6 pt-16 pb-12 flex flex-col items-center text-center rounded-b-[40px] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
           <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full blur-3xl"></div>
           <div className="absolute bottom-10 right-10 w-48 h-48 bg-white rounded-full blur-3xl"></div>
        </div>
        <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center mb-6 shadow-2xl rotate-3 overflow-hidden p-3 relative z-10">
          <img src={globalLogo} alt="Click Digital Logo" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-4xl font-black mb-2 tracking-tight">CLICK DIGITAL</h1>
        <p className="text-purple-100 opacity-90 text-sm max-w-xs leading-relaxed font-medium">
          {t.welcomeSub}
        </p>
      </header>

      {/* Main Content Area */}
      <main className="px-5 py-8 max-w-lg mx-auto -mt-8">
        
        {step === 'welcome' && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
            {/* Promo Carousel/Ads */}
            {ads.length > 0 && (
              <div className="space-y-4">
                 <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest px-2">{lang === 'EN' ? 'Featured Offers' : 'Ofa Maalum'}</h3>
                 <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x">
                    {ads.map(ad => (
                      <div key={ad.id} className="min-w-[85%] snap-center relative h-56 rounded-[32px] overflow-hidden shadow-2xl border-4 border-white group">
                        <img src={ad.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="Promo" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-6">
                          <h3 className="text-white font-bold text-lg leading-tight mb-2">{ad.text}</h3>
                          {ad.link && (
                            <a href={ad.link} target="_blank" rel="noreferrer" className="inline-flex items-center text-purple-300 text-xs font-bold uppercase tracking-wider gap-2">
                              {lang === 'EN' ? 'Claim Offer' : 'Pata Ofa'} <i className="fas fa-external-link-alt"></i>
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                 </div>
              </div>
            )}

            <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center mx-auto mb-4 p-2">
                <img src={globalLogo} alt="Logo Icon" className="w-full h-full object-contain opacity-80" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">{t.welcome}</h2>
              <button 
                onClick={() => setStep('browse')}
                className="w-full purple-gradient text-white font-bold py-5 rounded-[24px] shadow-purple-200 shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-3 text-lg"
              >
                {t.getStarted} <i className="fas fa-arrow-right"></i>
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-5 rounded-[32px] text-center border border-gray-100 shadow-sm">
                <div className="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-bolt text-purple-700"></i>
                </div>
                <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">{t.fastDelivery}</h3>
              </div>
              <div className="bg-white p-5 rounded-[32px] text-center border border-gray-100 shadow-sm">
                <div className="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-shield-alt text-purple-700"></i>
                </div>
                <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">{t.trustedQuality}</h3>
              </div>
            </div>
          </div>
        )}

        {step === 'browse' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-500">
            <div className="flex items-center gap-3">
               <button onClick={() => setStep('welcome')} className="p-3 bg-white rounded-2xl shadow-sm border border-gray-100 text-gray-400">
                 <i className="fas fa-arrow-left"></i>
               </button>
               <h2 className="text-xl font-bold text-gray-900">{t.browseServices}</h2>
            </div>
            
            {SERVICES.map((service) => (
              <div key={service.category} className="bg-white rounded-[32px] shadow-sm border border-gray-100 overflow-hidden">
                <button 
                  onClick={() => setActiveCategory(activeCategory === service.category ? null : service.category)}
                  className="w-full text-left p-6 flex items-center justify-between"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-700 text-xl">
                      {service.category === ServiceCategory.GRAPHIC_DESIGN && <i className="fas fa-paint-brush"></i>}
                      {service.category === ServiceCategory.WEBSITE_DESIGN && <i className="fas fa-globe"></i>}
                      {service.category === ServiceCategory.SOCIAL_MEDIA && <i className="fas fa-hashtag"></i>}
                      {service.category === ServiceCategory.QR_SOLUTIONS && <i className="fas fa-qrcode"></i>}
                      {service.category === ServiceCategory.LINK_IN_BIO && <i className="fas fa-link"></i>}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{service.categoryLabel[lang]}</h3>
                      <p className="text-xs text-gray-500">{service.options.length} {lang === 'EN' ? 'Packages' : 'Vifurushi'}</p>
                    </div>
                  </div>
                  <i className={`fas fa-chevron-down transition-transform duration-300 ${activeCategory === service.category ? 'rotate-180 text-purple-700' : 'text-gray-300'}`}></i>
                </button>

                {activeCategory === service.category && (
                  <div className="px-6 pb-6 space-y-4">
                    <p className="text-sm text-gray-500 italic mb-4">{service.description[lang]}</p>
                    {service.options.map((option) => (
                      <div key={option.id} className="bg-gray-50 p-5 rounded-3xl border border-gray-200">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-gray-900 pr-2">{option.name[lang]}</h4>
                          <span className="text-purple-700 font-black whitespace-nowrap">{formatCurrency(option.price)}</span>
                        </div>
                        <p className="text-xs text-gray-500 mb-3 leading-relaxed">{option.description[lang]}</p>
                        <div className="flex flex-wrap gap-2 mb-4">
                           {option.includes[lang].map((inc, i) => (
                             <span key={i} className="text-[10px] bg-white px-2 py-1 rounded-lg border border-gray-100 text-gray-600 font-medium">
                               <i className="fas fa-check text-green-500 mr-1"></i> {inc}
                             </span>
                           ))}
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
                            <i className="far fa-clock mr-1"></i> {t.delivery}: {option.deliveryTime[lang]}
                          </span>
                          <button 
                            onClick={() => addToCart(service.category, service.categoryLabel[lang], option)}
                            className="bg-purple-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-purple-100 active:scale-95 transition-all"
                          >
                            {lang === 'EN' ? 'Select Package' : 'Chagua Kifurushi'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {step === 'summary' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="flex items-center gap-3">
               <button onClick={() => setStep('browse')} className="p-3 bg-white rounded-2xl shadow-sm border border-gray-100 text-gray-400">
                 <i className="fas fa-arrow-left"></i>
               </button>
               <h2 className="text-xl font-bold text-gray-900">{t.summary}</h2>
            </div>

            {cart.length === 0 ? (
               <div className="bg-white p-12 rounded-[40px] text-center border border-gray-100">
                 <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                   <i className="fas fa-shopping-basket text-gray-200 text-3xl"></i>
                 </div>
                 <h3 className="text-lg font-bold text-gray-900 mb-2">{t.emptyCart}</h3>
                 <button onClick={() => setStep('browse')} className="text-purple-700 font-bold underline">{t.goBack}</button>
               </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
                  <div className="p-6 space-y-4">
                    {cart.map((item, i) => (
                      <div key={i} className="flex justify-between items-center bg-gray-50 p-4 rounded-2xl">
                        <div className="flex-1">
                          <p className="font-bold text-sm text-gray-900">{item.optionName}</p>
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{item.category}</p>
                        </div>
                        <div className="flex items-center gap-4">
                           <span className="font-black text-purple-700 text-sm">{formatCurrency(item.price)}</span>
                           <button onClick={() => removeFromCart(i)} className="w-8 h-8 rounded-full bg-red-50 text-red-400 flex items-center justify-center">
                             <i className="fas fa-times text-xs"></i>
                           </button>
                        </div>
                      </div>
                    ))}
                    
                    <div className="pt-6 border-t border-dashed border-gray-200">
                      <div className="flex justify-between items-center text-xl">
                        <span className="font-bold text-gray-900">{t.total}</span>
                        <span className="font-black text-purple-700">{formatCurrency(totalPrice)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-purple-50 p-6 flex items-start gap-4">
                    <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-purple-700 flex-shrink-0 shadow-sm">
                      <i className="fas fa-info-circle"></i>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-purple-900">{t.nextSteps}</h4>
                      <p className="text-xs text-purple-700 leading-relaxed mt-1 opacity-80">
                        {t.nextStepsDesc}
                      </p>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={sendToWhatsApp}
                  className="w-full bg-[#25D366] text-white font-bold py-6 rounded-[32px] shadow-2xl shadow-green-100 flex items-center justify-center gap-4 text-lg active:scale-95 transition-all"
                >
                  <i className="fab fa-whatsapp text-3xl"></i>
                  {t.placeOrder}
                </button>
              </div>
            )}
          </div>
        )}

        {step === 'admin' && (
          <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
            {!adminAuth ? (
              <div className="bg-white p-10 rounded-[40px] shadow-2xl border border-gray-100 text-center">
                <div className="w-20 h-20 bg-purple-50 rounded-3xl flex items-center justify-center mx-auto mb-6 p-3">
                  <img src={globalLogo} alt="Admin Logo" className="w-full h-full object-contain" />
                </div>
                <h2 className="text-2xl font-bold mb-6">{t.adminTitle}</h2>
                <input 
                  type="password" 
                  placeholder={t.password}
                  className="w-full p-5 bg-gray-50 border border-gray-100 rounded-2xl mb-4 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all text-center font-bold"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                />
                <button onClick={handleAdminLogin} className="w-full purple-gradient text-white py-5 rounded-2xl font-bold shadow-xl">{t.login}</button>
                <button onClick={() => setStep('welcome')} className="mt-6 text-sm text-gray-400 font-bold uppercase tracking-widest">{t.back}</button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex justify-between items-center bg-white p-6 rounded-[32px] shadow-sm border border-gray-100">
                   <h2 className="text-xl font-bold">{t.adminTitle}</h2>
                   <button onClick={() => setAdminAuth(false)} className="bg-red-50 text-red-500 px-4 py-2 rounded-xl text-xs font-bold uppercase">Logout</button>
                </div>

                {/* Logo Management */}
                <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
                  <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
                    <i className="fas fa-image text-purple-700"></i> {lang === 'EN' ? 'App Logo Management' : 'Usimamizi wa Logo ya App'}
                  </h3>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase ml-2">{t.uploadImage}</label>
                      <div className="relative border-2 border-dashed border-gray-200 rounded-2xl p-6 flex flex-col items-center justify-center bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer">
                        <input 
                          type="file" 
                          accept="image/*"
                          className="absolute inset-0 opacity-0 cursor-pointer"
                          onChange={handleLogoFileChange}
                        />
                        {previewLogo || globalLogo ? (
                          <div className="w-full space-y-3 flex flex-col items-center">
                             <img src={previewLogo || globalLogo} className="h-24 object-contain" alt="Logo Preview" />
                             <p className="text-[10px] text-purple-700 font-bold text-center">{lang === 'EN' ? 'Tap to Change Logo' : 'Gusa Kubadilisha Logo'}</p>
                          </div>
                        ) : (
                          <div className="text-center py-4">
                            <i className="fas fa-cloud-upload-alt text-2xl text-gray-300 mb-2"></i>
                            <p className="text-xs text-gray-400 font-bold">{t.uploadImage}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    <button 
                      onClick={saveLogo} 
                      disabled={!previewLogo}
                      className="w-full bg-purple-700 text-white py-5 rounded-2xl font-bold shadow-lg shadow-purple-100 mt-2 disabled:bg-gray-300 disabled:shadow-none transition-all"
                    >
                      {lang === 'EN' ? 'Save New Logo' : 'Hifadhi Logo Mpya'}
                    </button>
                  </div>
                </div>
                
                {/* Ad Manager */}
                <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
                  <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
                    <i className="fas fa-plus-circle text-purple-700"></i> {t.addAd}
                  </h3>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase ml-2">{t.headline}</label>
                      <input 
                        placeholder="e.g. 50% discount on first logo!" 
                        className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl"
                        value={newAd.text}
                        onChange={(e) => setNewAd({...newAd, text: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase ml-2">{t.imageUrl}</label>
                      <div className="relative border-2 border-dashed border-gray-200 rounded-2xl p-4 flex flex-col items-center justify-center bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer">
                        <input 
                          type="file" 
                          accept="image/*"
                          className="absolute inset-0 opacity-0 cursor-pointer"
                          onChange={handleAdFileChange}
                        />
                        {previewAdImage ? (
                          <div className="w-full space-y-3">
                             <img src={previewAdImage} className="w-full h-32 object-cover rounded-xl border border-gray-200" alt="Preview" />
                             <p className="text-[10px] text-purple-700 font-bold text-center">Change Image</p>
                          </div>
                        ) : (
                          <div className="text-center py-4">
                            <i className="fas fa-cloud-upload-alt text-2xl text-gray-300 mb-2"></i>
                            <p className="text-xs text-gray-400 font-bold">{t.uploadImage}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase ml-2">{t.linkUrl}</label>
                      <input 
                        placeholder="https://yourwebsite.com/promo" 
                        className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl"
                        value={newAd.link}
                        onChange={(e) => setNewAd({...newAd, link: e.target.value})}
                      />
                    </div>
                    <button 
                      onClick={addAd} 
                      disabled={!newAd.text || !previewAdImage}
                      className="w-full bg-green-500 text-white py-5 rounded-2xl font-bold shadow-lg shadow-green-100 mt-4 disabled:bg-gray-300 disabled:shadow-none"
                    >
                      {t.save}
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest px-2">{lang === 'EN' ? 'Active Promotions' : 'Matangazo Yaliyopo'}</h3>
                  {ads.length === 0 ? (
                    <p className="text-center text-gray-400 py-8 bg-white rounded-3xl border border-dashed">{t.noAds}</p>
                  ) : (
                    ads.map(ad => (
                      <div key={ad.id} className="bg-white p-4 rounded-[32px] border border-gray-100 flex gap-4 items-center shadow-sm">
                        <img src={ad.imageUrl} className="w-20 h-20 rounded-2xl object-cover flex-shrink-0" alt="" />
                        <div className="flex-1 overflow-hidden">
                          <p className="text-sm font-bold truncate text-gray-900">{ad.text}</p>
                          <p className="text-[10px] text-gray-400 truncate">{ad.link || 'No link'}</p>
                        </div>
                        <button onClick={() => deleteAd(ad.id)} className="w-10 h-10 rounded-full bg-red-50 text-red-500 flex items-center justify-center flex-shrink-0">
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    ))
                  )}
                </div>
                <button onClick={() => setStep('welcome')} className="w-full text-center text-gray-400 text-xs font-bold uppercase tracking-widest py-8">{t.back}</button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Floating Assistant Button */}
      <div className="fixed bottom-8 right-8 z-40 flex flex-col items-end">
        <div className="bg-white px-5 py-2.5 rounded-2xl shadow-xl border border-gray-100 mb-4 text-xs font-bold text-purple-700 animate-bounce flex items-center gap-2">
          {lang === 'EN' ? 'Need help?' : 'Unahitaji msaada?'} 👋
        </div>
        <button 
          onClick={() => setShowAssistant(true)}
          className="w-18 h-18 w-[72px] h-[72px] purple-gradient text-white rounded-[28px] shadow-2xl flex items-center justify-center text-3xl border-4 border-white hover:scale-110 active:scale-95 transition-all"
        >
          <i className="fas fa-comment-dots"></i>
        </button>
      </div>

      <Assistant 
        isOpen={showAssistant} 
        onClose={() => setShowAssistant(false)} 
        language={lang}
      />

      {/* Footer */}
      <footer className="px-6 py-12 text-center border-t border-gray-100 mt-12">
        <button onClick={() => setStep('admin')} className="px-6 py-3 bg-white rounded-2xl text-xs font-bold text-gray-400 hover:text-purple-700 border border-gray-100 shadow-sm transition-all uppercase tracking-widest">
          <i className="fas fa-lock mr-2"></i> {t.admin}
        </button>
        <p className="text-gray-300 text-[10px] mt-6 font-medium">© 2026 CLICK DIGITAL • CREATIVE EXCELLENCE</p>
      </footer>
    </div>
  );
};

export default App;
