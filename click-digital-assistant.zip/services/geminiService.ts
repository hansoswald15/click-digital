
import { GoogleGenAI } from "@google/genai";
import { SERVICES } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are the Click Digital Smart Assistant. 
Click Digital is a creative agency providing Graphic Design, Web Design, QR Code Solutions, and Social Media content.
Your tone is friendly, professional, and helpful.
Use TZS (Tanzanian Shillings) for all pricing references.

Current Pricing/Services Context:
- Logo Design: Basic (30,000 TZS), Standard (50,000 TZS), Premium Brand Kit (100,000 TZS)
- Poster/Flyer: Single (10,000 TZS), Package of 5 (50,000 TZS)
- Social Media: 5 posts (30,000 TZS), 10 posts (60,000 TZS)
- Website: One-page (200,000 TZS), Business (450,000 TZS)
- QR Code: Single (10,000 TZS), QR + Poster (25,000 TZS)
- Link-in-Bio: 25,000 TZS

Rules:
1. Always be concise. 
2. If asked about pricing, use the exact figures provided above.
3. If asked about payment, explain that payment details are shared after placing an order via WhatsApp.
4. Keep answers simple for non-technical users.
5. Provide answers in the language requested by the user (English or Swahili).
`;

export const getAssistantResponse = async (userPrompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text || "I'm sorry, I couldn't process that. Can you try rephrasing?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a little trouble connecting. Please try again later!";
  }
};
