
export enum ServiceCategory {
  GRAPHIC_DESIGN = 'Graphic Design',
  WEBSITE_DESIGN = 'Website Design',
  QR_SOLUTIONS = 'QR Code Solutions',
  SOCIAL_MEDIA = 'Social Media Design',
  LINK_IN_BIO = 'Link-in-Bio Setup'
}

export type Language = 'EN' | 'SW';

export interface ServiceOption {
  id: string;
  name: { EN: string; SW: string };
  price: number;
  deliveryTime: { EN: string; SW: string };
  description: { EN: string; SW: string };
  includes: { EN: string[]; SW: string[] };
}

export interface ServiceData {
  category: ServiceCategory;
  categoryLabel: { EN: string; SW: string };
  description: { EN: string; SW: string };
  options: ServiceOption[];
}

export interface CartItem {
  serviceId: string;
  category: ServiceCategory;
  optionName: string;
  price: number;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface Ad {
  id: string;
  text: string;
  imageUrl: string;
  link: string;
  active: boolean;
}
